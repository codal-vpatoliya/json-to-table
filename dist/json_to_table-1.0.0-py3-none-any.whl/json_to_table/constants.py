"""
Constants used throughout the json-to-table package.
"""

WS = " "
ES = ""
FORMAT = "utf8" 